# Tip Calculator

**Project For Newton School**
- HTML
- CSS
- JavaScript

![tip-calculator](https://user-images.githubusercontent.com/74202040/154133495-65c62a1e-3fce-460d-a72c-f78fe71fb31b.jpg)
